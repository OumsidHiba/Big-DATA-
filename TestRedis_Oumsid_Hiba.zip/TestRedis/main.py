import json_construction
import redis_insertion
import jointure_tests

# Exécuter la construction JSON
json_data = json_construction.construire_json_final("data/")
json_construction.sauvegarder_json(json_data, "data/data.json")

# Charger les données JSON et les insérer dans Redis
redis_insertion.inserer_dans_redis("data/data.json")

# Tester la jointure sur un attribut
with open("data/data.json", 'r') as f:
    data = json.load(f)

# Diviser les données et effectuer le test de jointure
items = list(data.items())
data_part1 = dict(items[:len(items) // 2])
data_part2 = dict(items[len(items) // 2:])
jointure_tests.jointure_sur_attribut(data_part1, data_part2, attribut="VilleD", valeur_cible="Marseille")
