import json
import os

# Dictionnaire pour les colonnes des fichiers
tableCorespondance = {
    "AVIONS.txt": ["NumAv", "NomAv", "CapAv", "VilleAv"],
    "CLIENTS.txt": ["NumCl", "NomCl", "NumRuelCl", "NomRueCl", "CodePosteCl", "VilleCl"],
    "DEFCLASSES.txt": ["NumVol", "Classe", "CoefPrix"],
    "PILOTES.txt": ["Numpil", "NomPil", "NaisPil", "VillePil"],
    "RESERVATIONS.txt": ["NumCl", "NumVol", "Classe", "NbPlaces"],
    "VOLS.txt": ["NumVol", "VilleD", "VilleA", "DateD", "HD time", "DateA", "HA time", "NumPil", "NumAv"],
}

def construire_json_final(dir_path):
    # Vérifions que le chemin des données existe
    if not os.path.exists(dir_path):
        print(f"Erreur : Le répertoire {dir_path} n'existe pas.")
        return {}

    dictAllJson = {}  # Stockage temporaire des données de chaque fichier
    for file_name in os.listdir(dir_path):
        # Vérifier les fichiers .txt uniquement
        if file_name.endswith(".txt"):
            print(f"Lecture du fichier : {file_name}")
            with open(os.path.join(dir_path, file_name), 'r') as f:
                name = os.path.basename(file_name)
                dictAllJson[name] = {}  # Préparer une entrée pour chaque fichier

                # Lecture ligne par ligne
                for line in f:
                    description = line.strip().split("\t")
                    if len(description) < len(tableCorespondance[name]):
                        print(f"Erreur dans le format de la ligne: {line}")
                        continue

                    # Associer chaque champ aux colonnes selon `tableCorespondance`
                    dictAllJson[name][description[0]] = {
                        tableCorespondance[name][i]: description[i] for i in range(1, len(description))
                    }
    
    # Construire jsonFinal avec les données intégrées
    jsonFinal = {}
    for vol in dictAllJson["VOLS.txt"]:
        jsonFinal[vol] = dictAllJson["VOLS.txt"][vol]

        # Associer les avions et pilotes au vol
        avion_id = dictAllJson["VOLS.txt"][vol].get("NumAv")
        pilote_id = dictAllJson["VOLS.txt"][vol].get("NumPil")

        if avion_id in dictAllJson["AVIONS.txt"]:
            jsonFinal[vol]["avion"] = dictAllJson["AVIONS.txt"][avion_id]
        else:
            print(f"Avion non trouvé pour {vol}")

        if pilote_id in dictAllJson["PILOTES.txt"]:
            jsonFinal[vol]["pilote"] = dictAllJson["PILOTES.txt"][pilote_id]
        else:
            print(f"Pilote non trouvé pour {vol}")

        jsonFinal[vol]["reservations"] = {}
        for reserv in dictAllJson["RESERVATIONS.txt"]:
            if vol == dictAllJson["RESERVATIONS.txt"][reserv]["NumVol"]:
                jsonFinal[vol]["reservations"][reserv] = dictAllJson["RESERVATIONS.txt"][reserv]

    return jsonFinal

def sauvegarder_json(json_data, file_path):
    # Vérifier que json_data n'est pas vide avant la sauvegarde
    if not json_data:
        print("Erreur : Les données JSON sont vides et ne peuvent pas être sauvegardées.")
        return

    # Sauvegarder le fichier
    with open(file_path, 'w') as f:
        json.dump(json_data, f, indent=4)
    print(f"Données sauvegardées avec succès dans {file_path}")

# Exécution principale pour construire et sauvegarder jsonFinal
if __name__ == "__main__":
    dir_path = "data"  # Remplacer par le chemin vers les fichiers .txt
    json_data = construire_json_final(dir_path)
    sauvegarder_json(json_data, "data/data.json")
