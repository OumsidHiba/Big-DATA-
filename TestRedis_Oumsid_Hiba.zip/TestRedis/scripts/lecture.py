import time
import redis

# Connexion à Redis
redis_client = redis.StrictRedis(
    host='localhost',  # Remplace par l'hôte Redis (par exemple, 'localhost' ou l'adresse de ton serveur Redis)
    port=6379,         # Port par défaut de Redis
    db=0               # Numéro de base de données Redis
)

def test_lecture_redis():
    # Obtenir toutes les clés
    keys = redis_client.keys('*')
    
    # Mesurer le temps de lecture
    start_time = time.time()
    
    # Lire chaque valeur associée aux clés
    for key in keys:
        key_type = redis_client.type(key).decode('utf-8')  # Obtenir le type de la clé
        if key_type == 'string':
            redis_client.get(key)  # Lire la valeur si c'est une chaîne
        else:
            print(f"Clé '{key.decode('utf-8')}' est de type '{key_type}', donc ignorée.")

    end_time = time.time()
    
    # Afficher le nombre de clés et le temps total de lecture
    print(f"Nombre de clés lues : {len(keys)}")
    print(f"Temps de lecture des données dans Redis : {end_time - start_time:.4f} secondes.")

# Exécution principale (si nécessaire)
if __name__ == "__main__":
    test_lecture_redis()
