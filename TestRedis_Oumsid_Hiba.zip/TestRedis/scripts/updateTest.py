import time
import redis

# Connexion à Redis
redis_conn = redis.StrictRedis(host='localhost', port=6379, db=0)

# Données de vol pour le test
vol_data = {"vol_id": "AF123", "depart": "Paris", "arrivee": "Londres", "statut": "à l'heure"}

# Insertion initiale des données dans Redis
redis_conn.hmset(f"vol:{vol_data['vol_id']}", vol_data)

# Mesure de la vitesse de mise à jour pour Redis
start_time = time.time()
for statut in ["en retard", "embarquement", "annulé"]:
    redis_conn.hset(f"vol:{vol_data['vol_id']}", "statut", statut)
    # Lecture des données après chaque mise à jour
    redis_conn.hgetall(f"vol:{vol_data['vol_id']}")
print("Redis Update time:", time.time() - start_time)