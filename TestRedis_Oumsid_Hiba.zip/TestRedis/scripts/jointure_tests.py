import json
import os

# Fonction pour tester les jointures sur un attribut donné
def jointure_sur_attribut(data1, data2, attribut, valeur_cible=None):
    jointures = []  # Liste pour stocker les résultats de jointure
    jointure_trouvee = False

    for key1, val1 in data1.items():
        for key2, val2 in data2.items():
            if attribut in val1 and attribut in val2:
                if valeur_cible:
                    if val1[attribut] == valeur_cible and val2[attribut] == valeur_cible:
                        print(f"Jointure trouvée entre {key1} et {key2} sur {attribut} avec la valeur '{valeur_cible}'")
                        jointures.append({key1: val1, key2: val2})  # Ajouter la jointure au résultat
                        jointure_trouvee = True
                elif val1[attribut] == val2[attribut]:
                    print(f"Jointure trouvée entre {key1} et {key2} sur {attribut} avec la valeur '{val1[attribut]}'")
                    jointures.append({key1: val1, key2: val2})  # Ajouter la jointure au résultat
                    jointure_trouvee = True

    if not jointure_trouvee:
        print(f"Aucune jointure trouvée sur {attribut} avec la valeur '{valeur_cible}'")
    
    return jointures  # Retourner la liste des jointures

# Fonction pour sauvegarder les résultats de la jointure dans un fichier JSON
def sauvegarder_jointures(jointures, nom_fichier):
    with open(nom_fichier, 'w') as f:
        json.dump(jointures, f, indent=4)
    print(f"Les résultats des jointures ont été sauvegardés dans '{nom_fichier}'")

# Fonction pour compter le nombre d'éléments dans le fichier JSON
def compter_elements_json(nom_fichier):
    with open(nom_fichier, 'r') as f:
        data = json.load(f)
    nb_elements = len(data)
    print(f"Nombre d'éléments dans '{nom_fichier}': {nb_elements}")
    return nb_elements

# Fonction pour obtenir la taille du fichier JSON
def taille_fichier_json(nom_fichier):
    taille = os.path.getsize(nom_fichier)
    print(f"Taille de '{nom_fichier}': {taille} octets")
    return taille

# Exemple d'exécution
if __name__ == "__main__":
    # Charger les données depuis le fichier data.json
    with open("data/data.json", 'r') as f:
        data = json.load(f)

    # Diviser les données pour le test
    items = list(data.items())
    data_part1 = dict(items[:len(items) // 2])
    data_part2 = dict(items[len(items) // 2:])

    # Effectuer la jointure sur l'attribut "VilleD"
    jointures = jointure_sur_attribut(data_part1, data_part2, attribut="VilleD", valeur_cible="Marseille")

    # Sauvegarder le résultat de la jointure dans un nouveau fichier JSON si des jointures ont été trouvées
    if jointures:
        nom_fichier_jointure = "data/jointure_result.json"
        sauvegarder_jointures(jointures, nom_fichier_jointure)

        # Compter le nombre d'éléments et obtenir la taille du fichier JSON
        compter_elements_json(nom_fichier_jointure)
        taille_fichier_json(nom_fichier_jointure)
