import time
import memory_profiler  # Assurez-vous que cette librairie est installée : pip install memory-profiler
import json_construction
import jointure_tests
import redis_insertion
import os
import json

# Mesurer la performance de la construction JSON
def test_construction_json():
    start_time = time.time()
    mem_before = memory_profiler.memory_usage()[0]
    
    # Construire le JSON
    json_data = json_construction.construire_json_final("data/")
    json_construction.sauvegarder_json(json_data, "data/data.json")
    
    end_time = time.time()
    mem_after = memory_profiler.memory_usage()[0]
    
    print(f"Construction JSON terminée en {end_time - start_time:.2f} secondes")
    print(f"Utilisation de la mémoire : {mem_after - mem_before:.2f} MiB")

# Mesurer la performance de la jointure
def test_jointure():
    # Charger les données
    with open("data/data.json", 'r') as f:
        data = json.load(f)
    
    # Diviser les données pour simuler deux ensembles
    items = list(data.items())
    data_part1 = dict(items[:len(items) // 2])
    data_part2 = dict(items[len(items) // 2:])
    
    # Mesurer la performance de la jointure
    start_time = time.time()
    mem_before = memory_profiler.memory_usage()[0]
    
    jointure_tests.jointure_sur_attribut(data_part1, data_part2, attribut="VilleD", valeur_cible="Marseille")
    
    end_time = time.time()
    mem_after = memory_profiler.memory_usage()[0]
    
    print(f"Jointure terminée en {end_time - start_time:.2f} secondes")
    print(f"Utilisation de la mémoire : {mem_after - mem_before:.2f} MiB")

# Mesurer la performance de l'insertion dans Redis
def test_insertion_redis():
    start_time = time.time()
    mem_before = memory_profiler.memory_usage()[0]
    
    # Insérer les données dans Redis
    redis_insertion.inserer_dans_redis("data/data.json")
    
    end_time = time.time()
    mem_after = memory_profiler.memory_usage()[0]
    
    print(f"Insertion Redis terminée en {end_time - start_time:.2f} secondes")
    print(f"Utilisation de la mémoire : {mem_after - mem_before:.2f} MiB")

# Lancer tous les tests
if __name__ == "__main__":

    print("\n--- Test de performance : Construction JSON ---")
    test_construction_json()
    
    print("\n--- Test de performance : Jointure ---")
    test_jointure()
    
    print("\n--- Test de performance : Insertion Redis ---")
    test_insertion_redis()
print('kkkkkkkkkkkkkkkkkkkkk')    