import json
import redis

# Connexion à Redis
r = redis.StrictRedis(host='localhost', port=6379, db=0, decode_responses=True)

# Charger et insérer les données dans Redis
def inserer_dans_redis(file_path):
    with open(file_path, 'r') as f:
        json_data = json.load(f)

    for vol in json_data:
        if int(vol[1:]) >= 101:  # Condition pour les vols à partir de V101
            key = f"vol:{vol}"
            r.set(key, json.dumps(json_data[vol]))  # Stocker chaque vol dans Redis
            print(f"Vol {vol} stocké dans Redis sous la clé {key}")

# Exécution principale pour insérer les données dans Redis
if __name__ == "__main__":
    inserer_dans_redis("data/data.json")
